package kz.iitu.demo.entity;

public enum BookStatus {
    RETURNED,
    REQUESTED,
    ISSUED,
    AVAILABLE
}
